from flask import Flask, request, jsonify, render_template, redirect, url_for, session
from flask_cors import CORS
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import os
import urllib.parse

app = Flask(__name__)
app.secret_key = 'your_secret_key'
CORS(app)

# Load skills dataset (Assume CSV with columns: Domain, Skills)
domains = pd.read_csv('domain.csv')  # Replace with actual path to your domain.csv
skills_column = domains['Skills']

# Initialize TfidfVectorizer
vectorizer = TfidfVectorizer(stop_words='english')

# Train the model using skills descriptions from domains
skills_matrix = vectorizer.fit_transform(skills_column)

# Handle resume file types (PDF/DOCX/TXT)
def read_pdf(file):
    import PyPDF2
    reader = PyPDF2.PdfReader(file)
    text = ""
    for page in reader.pages:
        text += page.extract_text()
    return text

def read_docx(file):
    import docx
    doc = docx.Document(file)
    text = ""
    for para in doc.paragraphs:
        text += para.text
    return text

def generate_naukri_search_url(role, location):
    """Generate Naukri search URL based on role and location."""
    role_encoded = role.replace(" ", "%20")
    location_encoded = location.replace(" ", "%20")
    
    # Naukri URL format (basic search)
    return f"https://www.naukri.com/{role_encoded}-jobs-in-{location_encoded}"

def generate_linkedin_search_url(domain, role, location, experience):
    """Generate LinkedIn search URL based on filters."""
    domain_encoded = domain.replace(" ", "%20")
    role_encoded = role.replace(" ", "%20")
    location_encoded = location.replace(" ", "%20")
    experience_encoded = experience.replace(" ", "%20")
    return f"https://www.linkedin.com/jobs/search/?keywords={role_encoded}&location={location_encoded}&f_I={domain_encoded}&experienceLevel={experience_encoded}"

def generate_indeed_search_url(role, location):
    """Generate Indeed search URL based on role and location."""
    role_encoded = role.replace(" ", "%20")
    location_encoded = location.replace(" ", "%20")
    
    # Indeed URL format (basic search)
    return f"https://www.indeed.com/jobs?q={role_encoded}&l={location_encoded}"

@app.route('/')
def welcome():
    """Render the welcome page."""
    return render_template('welcome.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    """Handle resume upload and domain prediction."""
    if request.method == 'POST':
        try:
            # Get uploaded resume
            resume = request.files['resume']
            file_extension = resume.filename.split('.')[-1].lower()
            if file_extension == 'pdf':
                resume_text = read_pdf(resume)
            elif file_extension == 'docx':
                resume_text = read_docx(resume)
            else:
                resume_text = resume.read().decode('utf-8')

            # Extract skills from the resume
            resume_skills = vectorizer.transform([resume_text])

            # Calculate similarity with domains in the dataset
            similarities = cosine_similarity(resume_skills, skills_matrix).flatten()
            best_match_idx = similarities.argmax()
            predicted_domain = domains.iloc[best_match_idx]['Domain']

            # Save predicted domain in session
            session['predicted_domain'] = predicted_domain
            return redirect(url_for('details'))

        except Exception as e:
            print(f"Error: {str(e)}")
            return jsonify({'error': str(e)})

    return render_template('upload.html')

@app.route('/details', methods=['GET', 'POST'])
def details():
    """Ask for additional details like experience, location, and role."""
    if request.method == 'POST':
        try:
            # Get user inputs
            location = request.form.get('location', '').strip()
            experience = request.form.get('experience', '').strip()
            role = request.form.get('role', '').strip()

            # Save inputs to session
            session['location'] = location
            session['experience'] = experience
            session['role'] = role

            return redirect(url_for('select_platform'))

        except Exception as e:
            print(f"Error: {str(e)}")
            return jsonify({'error': str(e)})

    # Render details page
    predicted_domain = session.get('predicted_domain', 'Unknown')
    return render_template('details.html', domain=predicted_domain)

@app.route('/select_platform', methods=['GET', 'POST'])
def select_platform():
    """Allow the user to select LinkedIn, Naukri, or Indeed for job search."""
    if request.method == 'POST':
        # Get the selected platform (LinkedIn, Naukri, or Indeed)
        platform = request.form.get('platform')
        
        domain = session.get('predicted_domain', 'Unknown')
        location = session.get('location', 'Unknown')
        experience = session.get('experience', 'Unknown')
        role = session.get('role', 'Unknown')

        if platform == 'linkedin':
            linkedin_url = generate_linkedin_search_url(domain, role, location, experience)
            return redirect(linkedin_url)
        elif platform == 'naukri':
            naukri_url = generate_naukri_search_url(role, location)
            return redirect(naukri_url)
        elif platform == 'indeed':
            indeed_url = generate_indeed_search_url(role, location)
            return redirect(indeed_url)
        else:
            return jsonify({'error': 'Invalid platform selection'})

    return render_template('select_platform.html')

@app.route('/result')
def result():
    """Redirect to the selected job search page."""
    try:
        domain = session.get('predicted_domain', 'Unknown')
        location = session.get('location', 'Unknown')
        experience = session.get('experience', 'Unknown')
        role = session.get('role', 'Unknown')

        # Generate LinkedIn, Naukri, or Indeed URL based on platform selection
        search_platform = 'naukri'  # Default to Naukri, can be set dynamically by user
        if search_platform == 'naukri':
            search_url = generate_naukri_search_url(role, location)
        elif search_platform == 'linkedin':
            search_url = generate_linkedin_search_url(domain, role, location, experience)
        elif search_platform == 'indeed':
            search_url = generate_indeed_search_url(role, location)

        return redirect(search_url)

    except Exception as e:
        print(f"Error: {str(e)}")
        return jsonify({'error': str(e)})

if __name__ == "__main__":
    app.run(debug=True)




